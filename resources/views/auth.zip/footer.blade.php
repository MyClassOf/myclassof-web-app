<div class="container">
    <footer class="pt-4 pt-4">
        <div class="row">
            <div class="col-md-4 ftr-a">
                <h3 style="text-align: left; color: #ffffff">The Fine Print</h3>
                <p><span>&nbsp;</span></p>
                <p ><a href='http://dev.myclassof.com/resources/views/legal.html'>Legal Notice</a></p>
                <p ><a href="http://dev.myclassof.com/resources/views/condition.html">Conditions of Use</a></p>
                <p ><a href='http://dev.myclassof.com/resources/views/privacy.html'>Privacy Notice</a></p>
            </div>

            <div class="col-md-4 ftr-a">
                <h3 style="text-align: left; color: #ffffff ">My Class Of <span style="font-size: 25px; vertical-align: text-top;">®</span></h3>
                <p><span >&nbsp;</span></p>
                <p ><a href='http://dev.myclassof.com/resources/views/whoweare.html'>Who We Are</a></p>
                <p ><a href="http://dev.myclassof.com/resources/views/ourservices.html">Our Services</a></p>
                <p ><a href="http://dev.myclassof.com/public/support">Support</a></p>
            </div>

            <div class="col-md-4 ftr-a">
                <h3 style="text-align: left; color: #ffffff">Find us</h3>
                <p>&nbsp;</p>
                <p >P O Box 252</p>
                <p >Bartlett, TN 38134</p>
                <p ><a href="http://dev.myclassof.com/resources/views/contactus.html">Contact us</a></p>
                <p >Call us +1&nbsp; (901) 213-8171</span></p>
                <a href="https://www.facebook.com/myclassof" class="fa fa-facebook"></a>
                <a href="https://twitter.com/myclassof" class="fa fa-twitter"></a>
                <a href="https://instagram.com/myclassof" class="fa fa-instagram"></a>
                <a href="https://pinterest.com/myclassof" class="fa fa-pinterest "></a>
            </div>
            <div class="smue-text-obj">
                <p><span style="font-size: 12px; color: #333333">Copyright © {{ date("Y") }} myclassof</span></p>

            </div>

          
    </footer>

</div>
