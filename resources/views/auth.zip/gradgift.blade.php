@extends('layouts.app')

@section('style')
    <style>
        .fa {
            padding: 4px;
            font-size: 24px;
            width: 35px;
            text-align: center;
            text-decoration: none;
            margin: 5px 2px;
        }

        .fa:hover {
            opacity: 0.7;
        }

        .fa-facebook {
            background: #3B5998;
            color: white;
        }

        .fa-twitter {
            background: #55ACEE;
            color: white;
        }

        .fa-google {
            background: #dd4b39;
            color: white;
        }

        .fa-linkedin {
            background: #007bb5;
            color: white;
        }

        .fa-youtube {
            background: #bb0000;
            color: white;
        }

        .fa-instagram {
            background: #125688;
            color: white;
        }

        .fa-pinterest {
            background: #cb2027;
            color: white;
        }

        .fa-snapchat-ghost {
            background: #fffc00;
            color: white;
            text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
        }

        .fa-skype {
            background: #00aff0;
            color: white;
        }

        .fa-android {
            background: #a4c639;
            color: white;
        }

        .fa-dribbble {
            background: #ea4c89;
            color: white;
        }

        .fa-vimeo {
            background: #45bbff;
            color: white;
        }

        .fa-tumblr {
            background: #2c4762;
            color: white;
        }

        .fa-vine {
            background: #00b489;
            color: white;
        }

        .fa-foursquare {
            background: #45bbff;
            color: white;
        }

        .fa-stumbleupon {
            background: #eb4924;
            color: white;
        }

        .fa-flickr {
            background: #f40083;
            color: white;
        }

        .fa-yahoo {
            background: #430297;
            color: white;
        }

        .fa-soundcloud {
            background: #ff5500;
            color: white;
        }

        .fa-reddit {
            background: #ff5700;
            color: white;
        }

        .fa-rss {
            background: #ff6600;
            color: white;
        }

        .emp {
            color: #fff;
            font-size: 3em;
            margin-bottom: 30px;
            line-height: inherit;
            letter-spacing: -1px;
        }

        .margin-top {
            margin-top:7em;
        }

        .light{

        }

        .abc {
            position: relative;
            width: 100%;
        }

        .image {
            opacity: 1;
            display: block;
            width: 100%;
            height: auto;
            transition: .5s ease;
            backface-visibility: hidden;
        }

        .middle {
            transition: .5s ease;
            opacity: 0;
            position: absolute;
            top: 50%;
            left:50%;
            transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            text-align: center;
        }

        .abc:hover .image {
            opacity: 0.3;
        }

        .abc:hover .middle {
            opacity: 1;
        }

        .text {
            /* background-color: #4CAF50;*/
            color: white;
            font-size: 40px;
            padding: 16px 16px;
        }

        .name {
            margin-top: 15px;
            margin-bottom: 1rem;
        }
        .paypal-width{
            width: 200px;
        }


    </style>
@endsection

@section('content')

    <div class="container">

        <div class="row margin-top">

        </div>


        <div class="abc">
            <img src="{{asset('images/grad/ZHejqo.jpg')}}" alt="Avatar" class="image" style="width:100%">
            <div class="middle">
                <div class="text"><h1>Welcome to the grad gift page!</h1>
                </div>
                <div class="text"><h1>Select the items you would like to made purchasable in your Grad Gift account.</h1>
                </div>
            </div>
        </div>

        <div class="row pt-4 pb-4">

        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/blender.jpg')}}" width="100%">
                    </div>
                </div>
                <div class="name">$75 Grad Gift – Blender  </div>
                <div id="paypal-button-container" class="paypal-width"></div>
                
                
            </div>
            <div class="col-md-4">
                <div class="card , img-thumbnail" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/books.jpg')}}" width="100%">

                    </div>
                </div>
                <div class="name">$125 Grad Gift – The gift of Semester Books</div>

            </div>
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/notebook-ipad.jpg')}}" width="100%">

                    </div>
                </div>
                <div class="name">$250 Grad Gift – A new laptop!</div>
            </div>


        </div>
        <div class="row pt-4">
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/pots-and-pans.jpg')}}" width="100%">

                    </div>
                </div>
                <div class="name">$100 Grad Gift – Pots and Pans</div>
            </div>
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/refrigerator.jpg')}}" width="100%">

                    </div>
                </div>

                <div class="name">$200 Grad Gift – Mini Fridge for my room!</div>
            </div>
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/tacobell.jpg')}}" width="100%">
                    </div>
                </div>
                <div class="name">$50 Grad Gift – Week’s Worth of Fast Food</div>
            </div>


        </div>
        <div class="row pt-4">
            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/sweatshirts.jpg')}}" width="100%">

                    </div>
                </div>
                <div class="name">$75 Grad Gift – New College Sweatshirt</div>
            </div>

            <div class="col-md-4">
                <div class="card" style="width : 60%">
                    <div class="card-body">
                        <img src="{{asset('images/grad/tablets.jpg')}}" width="100%">

                    </div>
                </div>
                <div class="name">$125 Grad Gift – A new Tablet!</div>
            </div>
            
        </div>
    </div>
    
     <script src="https://www.paypal.com/sdk/js?client-id=sb&currency=USD" data-sdk-integration-source="button-factory">
     </script> <script> paypal.Buttons({ style: { shape: 'pill', color: 'silver', layout: 'vertical', label: 'pay', }, createOrder: function(data, actions) { return actions.order.create({ purchase_units: [{ amount: { value: '1' } }] }); }, onApprove: function(data, actions) { return actions.order.capture().then(function(details) { alert('Transaction completed by ' + details.payer.name.given_name + '!'); }); } }).render('#paypal-button-container'); </script>


@endsection

