@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center py-5">
            <div class="col-md-12 text-center">
                <form action="{{ route('account.detail') }}" method="post">
                    {{ csrf_field() }}
                    <p style="font-size: 25px; font-weight: 700;">Would you like to create Grad Gift Account?</p>
                    <div id="yes">
                        <input id="label1" type="radio" name="ans" value="1">
                        <label for="label1">YES</label>
                    </div>
                    <div id="no">
                        <input id="label2" type="radio" name="ans" checked value="0">
                        <label for="label2">NO</label><br>
                    </div>
                    <div id="txt-box">
                    <input type="email" name="paypal" placeholder="Enter your paypal email address"><br>
                    <label>OR</label><br>
                    <input type="text" name="acc_no" placeholder="Enter your account number">
                    <input type="text" name="acc_pin" placeholder="Enter your account routing number">
                    </div><br>
                    <!--<textarea class="mb-5" style="display: none;"  cols="50" rows="1" name="deatiled_answer"-->
                    <!--          placeholder="Enter paypal or account deatils"></textarea><br>-->
                    <input type="submit" value="Next" class="btn-next">
                        
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $('#label1').click(function () {
                $('#txt-box').show('slow');
            });
            $('#label2').click(function () {
                $('#txt-box').hide('slow');
            });
        });
    </script>
@endsection
