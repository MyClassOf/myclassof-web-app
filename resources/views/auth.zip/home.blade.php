@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center py-5">
            <div class="col-md-12 text-center">
                <form action="{{ route('question') }}" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" value="{{$question->id}}" name="ques_id">
                    <p style="font-size: 25px; font-weight: 700;">{{ $question->question }}</p>
                    <div id="yes">
                        <input id="label1" type="radio" name="ans" value="1">
                        <label for="label1">YES</label>
                    </div>
                    <div id="no">
                        <input id="label2" type="radio" name="ans" checked value="0">
                        <label for="label2">NO</label><br>
                    </div>
                    <input class="mb-5" style="display: none;" id="txt-box" cols="50" rows="1" name="deatiled_answer"
                              placeholder="Enter your detailed answer"></input><br>
{{--                    <a href="{{ route('questions',$question->id + 1) }}" class="btn-next">Next</a>--}}
                    @if($question->id > 1)
                        <a href="{{ route('questions',$question->id - 1) }}" class="btn-next">Back</a>
                    @endif()
                    <input type="submit" value="Next" class="btn-next">
                    <a href="{{ route('questions',$question->id + 1) }}" class="btn-next">Skip</a>
                        
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $('#label1').click(function () {
                $('#txt-box').show('slow');
            });
            $('#label2').click(function () {
                $('#txt-box').hide('slow');
            });
        });
    </script>
@endsection
